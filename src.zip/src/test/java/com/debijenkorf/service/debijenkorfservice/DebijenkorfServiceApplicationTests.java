package com.debijenkorf.service.debijenkorfservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebijenkorfServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
