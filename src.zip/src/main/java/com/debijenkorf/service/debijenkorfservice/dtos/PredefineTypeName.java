package com.debijenkorf.service.debijenkorfservice.dtos;

public enum PredefineTypeName {
    thumbnail, original;
}
