package com.debijenkorf.service.debijenkorfservice.utils;

import org.springframework.stereotype.Component;

@Component
public class AmazonS3Utitlity {


}
